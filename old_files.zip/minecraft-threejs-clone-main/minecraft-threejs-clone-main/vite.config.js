/**
* @type {import('vite').UserConfig}
*/
export default {
  base: '/minecraft-threejs-clone/',
  build: {
    sourcemap: true
  }
}