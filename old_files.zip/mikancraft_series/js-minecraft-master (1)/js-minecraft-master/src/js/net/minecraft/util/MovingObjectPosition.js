export default class MovingObjectPosition {

    constructor(vector, face, x, y, z) {
        this.vector = vector;
        this.face = face;

        this.x = x;
        this.y = y;
        this.z = z;
    }
}