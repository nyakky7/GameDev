export default class Slot {

    constructor(inventory, index, x, y) {
        this.inventory = inventory;
        this.index = index;
        this.x = x;
        this.y = y;
    }

}