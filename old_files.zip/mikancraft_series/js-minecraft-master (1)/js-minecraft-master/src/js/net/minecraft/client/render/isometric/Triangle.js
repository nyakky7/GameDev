export default class Triangle {
    constructor(p0, p1, p2, t0, t1, t2) {
        this.p0 = p0;
        this.p1 = p1;
        this.p2 = p2;

        this.t0 = t0;
        this.t1 = t1;
        this.t2 = t2;
    }
}