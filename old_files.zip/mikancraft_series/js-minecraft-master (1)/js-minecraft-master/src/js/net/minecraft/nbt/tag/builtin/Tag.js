export default class Tag {
    constructor(name) {
        this.name = name;
    }

    getName() {
        return this.name;
    }

    write(buffer) {

    }

    read(buffer) {

    }
}