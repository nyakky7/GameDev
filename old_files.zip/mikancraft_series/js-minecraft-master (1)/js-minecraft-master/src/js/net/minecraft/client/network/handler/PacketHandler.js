export default class PacketHandler {

    onConnect() {

    }

    onDisconnect() {

    }
}