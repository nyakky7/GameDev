export default class EnumSkyBlock {
    static SKY = 0;
    static BLOCK = 1;
}