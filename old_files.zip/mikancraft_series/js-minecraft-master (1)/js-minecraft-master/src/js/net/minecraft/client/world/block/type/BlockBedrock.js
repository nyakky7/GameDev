import Block from "../Block.js";

export default class BlockBedrock extends Block {

    constructor(id, textureSlotId) {
        super(id, textureSlotId);
    }

}