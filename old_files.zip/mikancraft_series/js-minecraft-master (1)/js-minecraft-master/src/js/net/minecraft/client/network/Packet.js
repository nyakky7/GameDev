export default class Packet {

    constructor() {

    }

    write(buffer) {

    }

    read(buffer) {

    }

    handle(packetHandler) {

    }

}