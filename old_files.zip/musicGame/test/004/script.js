const startBtn = document.getElementById("startBtn");
const countdownEl = document.getElementById("countdown");
const comboDisplay = document.getElementById("comboDisplay");

const directions = [
  "lane1", "lane2", "lane3", "lane4",
  "lane5", "lane6", "lane7", "lane8"
];

const keyMap = {
  KeyA: "lane1",
  KeyS: "lane2",
  KeyD: "lane3",
  KeyF: "lane4",
  KeyJ: "lane5",
  KeyK: "lane6",
  KeyL: "lane7",
  Semicolon: "lane8"
};

let notes = [];
let combo = 0;
let gameStarted = false;
let moveInterval;

// === 自動生成用設定 ===
const noteFallTime = 2.0;
const bpm = 120;
const beatInterval = 60 / bpm;
const chartRaw = [];
const startDelay = 3.0; // ノーツを3秒遅らせて出現

for (let i = 0; i < 120; i++) {
  const time = i * beatInterval + startDelay;
  const randomLane = directions[Math.floor(Math.random() * directions.length)];
  chartRaw.push({ time, lane: randomLane });
}

let chart = chartRaw.map(n => ({
  time: n.time - noteFallTime, // 出現タイミング
  lane: n.lane,
  hitTime: n.time              // ヒットタイミング
}));

startBtn.addEventListener("click", () => {
  startBtn.style.display = "none";
  startCountdown();
});

function startCountdown() {
  let count = 3;
  countdownEl.textContent = count;

  const countdownInterval = setInterval(() => {
    count--;
    if (count > 0) {
      countdownEl.textContent = count;
    } else if (count === 0) {
      countdownEl.textContent = "START!!";
    } else {
      clearInterval(countdownInterval);
      countdownEl.textContent = "";
      startGame();
    }
  }, 1000);
}

function startGame() {
  gameStarted = true;

  const bgm = document.getElementById("bgm");
  bgm.currentTime = 0;
  bgm.play();

  requestAnimationFrame(gameLoop);
  moveNotes();
  updateCombo(0);
}

function spawnNote(lane, hitTime) {
  const el = document.createElement("div");
  el.className = `note ${lane}`;
  el.textContent = getKeySymbol(lane);
  const laneElement = document.getElementById(lane);
  laneElement.appendChild(el);

  notes.push({ el, lane, y: -30, hitTime });
}

function getKeySymbol(lane) {
  const map = {
    lane1: "A", lane2: "S", lane3: "D", lane4: "F",
    lane5: "J", lane6: "K", lane7: "L", lane8: ";"
  };
  return map[lane];
}

function gameLoop() {
  const bgm = document.getElementById("bgm");
  const currentTime = bgm.currentTime;

  while (chart.length > 0 && chart[0].time <= currentTime) {
    const { lane, hitTime } = chart.shift();
    spawnNote(lane, hitTime);
  }

  if (gameStarted) requestAnimationFrame(gameLoop);

  // ノーツも譜面も残っていなければBGM停止 & ゲーム終了
  if (chart.length === 0 && notes.length === 0) {
    bgm.pause();
    endGame();
  }
}

function moveNotes() {
  moveInterval = setInterval(() => {
    const bgm = document.getElementById("bgm");
    const currentTime = bgm.currentTime;

    for (let i = notes.length - 1; i >= 0; i--) {
      const note = notes[i];
      const t = note.hitTime - currentTime;
      const y = (1 - t / noteFallTime) * 500;

      if (y > 500) {
        note.el.remove();
        notes.splice(i, 1);
        combo = 0;
        updateCombo(combo);
        showResult("Miss", document.getElementById(note.lane));
      } else {
        note.y = y;
        note.el.style.top = y + "px";
      }
    }
  }, 16);
}

document.addEventListener("keydown", (e) => {
  const dir = keyMap[e.code];
  if (!dir || !gameStarted || e.repeat) return;

  const now = document.getElementById("bgm").currentTime;
  let matched = false;

  for (let i = 0; i < notes.length; i++) {
    const note = notes[i];
    if (note.lane !== dir) continue;

    const delta = Math.abs(note.hitTime - now);
    let result = null;

    if (delta <= 0.1) result = "Perfect";
    else if (delta <= 0.2) result = "Good";
    else if (delta <= 0.3) result = "Bad";

    if (result) {
      note.el.remove();
      notes.splice(i, 1);
      matched = true;

      combo = result === "Bad" ? 0 : combo + 1;
      updateCombo(combo);
      showResult(result, document.getElementById(dir));
      break;
    }
  }

  if (!matched) {
    combo = 0;
    updateCombo(combo);
    showResult("Miss", document.getElementById(dir));
  }
});

function showResult(text, lane) {
  const result = document.createElement("div");
  result.className = "result";
  result.textContent = text;
  lane.appendChild(result);

  setTimeout(() => result.remove(), 1000);
}

function updateCombo(value) {
  comboDisplay.textContent = `COMBO: ${combo}`;
}

function endGame() {
  clearInterval(moveInterval);
  notes.forEach(n => n.el.remove());
  notes = [];

  alert(`ゲーム終了！\n最終コンボ: ${combo}`);
  location.reload();
}
