import Block from "../Block.js";

export default class BlockStone extends Block {

    constructor(id, textureSlotId) {
        super(id, textureSlotId);
    }

}