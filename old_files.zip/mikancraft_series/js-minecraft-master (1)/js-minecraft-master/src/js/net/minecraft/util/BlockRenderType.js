export default class BlockRenderType {
    static BLOCK = 0;
    static TORCH = 1;
}