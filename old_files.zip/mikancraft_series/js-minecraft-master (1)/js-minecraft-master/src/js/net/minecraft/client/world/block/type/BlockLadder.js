import Block from "../Block.js";
import BoundingBox from "../../../../util/BoundingBox.js";
import BlockRenderType from "../../../../util/BlockRenderType.js";
import EnumBlockFace from "../../../../util/EnumBlockFace.js";


export default class BlockLadder extends Block {
    constructor(id, textureSlotId) {
        super(id, textureSlotId);

        // 梯子は薄いので、前面に近い板状の当たり判定
        this.boundingBox = new BoundingBox(0.0, 0.0, 0.875, 1.0, 1.0, 1.0); // 壁に貼り付く形

        this.sound = Block.sounds.wood;
    }

    getRenderType() {
        return BlockRenderType.BLOCK; // 普通の描画でもOK（必要なら板描画にする）
    }

    isClimbable() {
        return true; // プレイヤーが登れるように（※登り処理が必要）
    }

    isSolid() {
        return false; // 通り抜けできる
    }

    getOpacity() {
        return 0.0;
    }

    isTranslucent() {
        return true;
    }

    getTransparency() {
        return 0.0;
    }

  onBlockPlaced(world, x, y, z, face) {
    let direction = 0;
    switch (face) {
        case EnumBlockFace.NORTH: direction = 0; break;
        case EnumBlockFace.SOUTH: direction = 1; break;
        case EnumBlockFace.WEST:  direction = 2; break;
        case EnumBlockFace.EAST:  direction = 3; break;
    }

    // 保存する（方向に応じた値）
    world.setBlockDataAt(x, y, z, direction);
}


getBoundingBox(world, x, y, z) {
    if (!world) {
        // GUI描画時など、ワールド情報が無いときはデフォルト形状
        return new BoundingBox(0.0, 0.0, 0.875, 1.0, 1.0, 1.0);
    }

    const data = world.getBlockDataAt(x, y, z);

    switch (data) {
        case 0: // NORTH
            return new BoundingBox(0.0, 0.0, 0.875, 1.0, 1.0, 1.0);
        case 1: // SOUTH
            return new BoundingBox(0.0, 0.0, 0.0, 1.0, 1.0, 0.125);
        case 2: // WEST
            return new BoundingBox(0.875, 0.0, 0.0, 1.0, 1.0, 1.0);
        case 3: // EAST
            return new BoundingBox(0.0, 0.0, 0.0, 0.125, 1.0, 1.0);
        default:
            return this.boundingBox;
    }
}

// getBoundingBox(world, x, y, z) {
//     const data = world.getBlockDataAt(x, y, z);

//     switch (data) {
//         case 0: // NORTH
//             return new BoundingBox(0.0, 0.0, 0.875, 1.0, 1.0, 1.0);
//         case 1: // SOUTH
//             return new BoundingBox(0.0, 0.0, 0.0, 1.0, 1.0, 0.125);
//         case 2: // WEST
//             return new BoundingBox(0.875, 0.0, 0.0, 1.0, 1.0, 1.0);
//         case 3: // EAST
//             return new BoundingBox(0.0, 0.0, 0.0, 0.125, 1.0, 1.0);
//         default:
//             return this.boundingBox;
//     }
// }

    getColor(world, x, y, z, face) {
        return 0x996633; // 茶色（オプション）
    }
}
