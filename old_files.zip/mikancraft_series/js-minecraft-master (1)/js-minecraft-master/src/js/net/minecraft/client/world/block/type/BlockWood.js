import Block from "../Block.js";

export default class BlockWood extends Block {

    constructor(id, textureSlotId) {
        super(id, textureSlotId);
    }

}