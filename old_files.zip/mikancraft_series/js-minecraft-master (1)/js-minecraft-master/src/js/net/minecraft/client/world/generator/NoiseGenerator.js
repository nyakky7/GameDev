export default class NoiseGenerator {
    perlin(x, z) {

    }
}