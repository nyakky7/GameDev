import Container from "../Container.js";

export default class ContainerPlayer extends Container {

    constructor() {
        super();

    }


}