import Packet from "../../../Packet.js";

export default class StatusQueryPacket extends Packet {

    constructor() {
        super();
    }

    write(buffer) {
    }

    read(buffer) {
    }
}