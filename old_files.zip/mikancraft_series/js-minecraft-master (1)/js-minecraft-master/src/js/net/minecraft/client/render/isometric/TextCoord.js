export default class TextCoord {
    constructor(u, v) {
        this.u = u ? u : 0;
        this.v = v ? v : 0;
    }
}