import Packet from "../../../Packet.js";

export default class ClientSwingArmPacket extends Packet {

    constructor() {
        super();
    }
}