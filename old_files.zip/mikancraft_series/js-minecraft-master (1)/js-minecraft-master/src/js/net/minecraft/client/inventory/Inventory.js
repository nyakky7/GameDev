export default class Inventory {

    constructor(name) {
        this.name = name;
    }

    getItemInSlot(index) {

    }

    setItem(index, typeId) {

    }

}