// import Block from "../Block.js";
// // import BlockRenderType from "../util/BlockRenderType.js";
// //import BlockRenderType from "../../net/minecraft/util/BlockRenderType.js";
// import BlockRenderType from "../../../util/BlockRenderType.js";
import Block from "../Block.js";
import BlockRenderType from "../../../../util/BlockRenderType.js";



export default class BlockRed extends Block {
    constructor(id, textureSlotId) {
        super(id, 15); // ← スロット番号を 15 に変更（左から16番目）


        // 必要に応じて音も設定
        this.sound = Block.sounds.stone;
    }

    getTransparency() {
        return 0.0;
    }

    isTranslucent() {
        return false;
    }

    getOpacity() {
        return 1.0;
    }

    getRenderType() {
        return BlockRenderType.BLOCK; // ← これが非常に重要！
    }

    getColor(world, x, y, z, face) {
        return 0xff0000; // 見た目の補助（赤）
    }
}
