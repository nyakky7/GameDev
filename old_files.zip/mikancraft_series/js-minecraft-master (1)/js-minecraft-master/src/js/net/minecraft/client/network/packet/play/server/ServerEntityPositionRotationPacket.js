import ServerEntityMovementPacket from "./ServerEntityMovementPacket.js";

export default class ServerEntityPositionRotationPacket extends ServerEntityMovementPacket {

    constructor() {
        super();

        this.position = true;
        this.position = true;
    }
}